public class TestEmployee {
    public static void main(String[] args) {
        // Test Employee
        Employee emp = new Employee();
        emp.setFirstName("John");
        emp.setLastName("Doe");
        emp.setEmployeeID(1001);
        emp.setSalary(50000);
        emp.employeeSummary();

        System.out.println();

        // Test Manager
        Manager mgr = new Manager();
        mgr.setFirstName("Jane");
        mgr.setLastName("Smith");
        mgr.setEmployeeID(1002);
        mgr.setSalary(80000);
        mgr.setDepartment("Engineering");
        mgr.employeeSummary();
    }
}
